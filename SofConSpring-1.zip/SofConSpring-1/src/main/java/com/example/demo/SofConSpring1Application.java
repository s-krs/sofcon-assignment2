package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SofConSpring1Application {

	public static void main(String[] args) {
		SpringApplication.run(SofConSpring1Application.class, args);
	}

}
